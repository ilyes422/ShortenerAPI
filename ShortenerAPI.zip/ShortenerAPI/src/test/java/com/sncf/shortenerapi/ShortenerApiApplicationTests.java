package com.sncf.shortenerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShortenerApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
