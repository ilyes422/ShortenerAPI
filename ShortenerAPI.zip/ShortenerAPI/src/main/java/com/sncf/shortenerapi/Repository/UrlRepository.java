package com.sncf.shortenerapi.Repository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sncf.shortenerapi.Model.Url;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;
import java.io.File;
import java.io.IOException;
import java.util.List;

@Repository
public class UrlRepository {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    @Value("${json.file.path}")
    private static String jsonFile;


    public static List<Url> findAll() throws IOException {
        return objectMapper.readValue(jsonFile, objectMapper.getTypeFactory().constructCollectionType(List.class, Url.class));
    }

    public static Url save(Url newUrl) throws IOException {
        List<Url> urls = findAll();
        urls.add(newUrl);
        objectMapper.writeValue(new File(jsonFile), urls);
        return newUrl;
    }

    public void delete(Url url) {
    }

    public Url findById(String id) {
        return null;
    }
}

