package com.sncf.shortenerapi.Service;

import com.sncf.shortenerapi.Model.Url;
import com.sncf.shortenerapi.Repository.UrlRepository;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

@Service


public class UrlService {

    private final UrlRepository urlRepository;

    public UrlService(UrlRepository urlRepository) {
        this.urlRepository = urlRepository;
    }

    /*Fonction de récupération d'URL*/
    public List<Url> getUrls() throws IOException {
        return UrlRepository.findAll();
    }
    /*Fonction de création d'une mini URL*/
    public Url createShortUrl(String originalUrl) throws IOException {

        Url newUrl;
        newUrl = new Url(null, generateShortUrl(), originalUrl);

        return UrlRepository.save(newUrl);
    }
    /*Fonction de suppression d'URL*/
    public void deleteUrl(String id, String removalToken) throws IOException {

        Url url;
        url = urlRepository.findById(id);

        if (url != null && url.getRemovalToken().equals(removalToken)) {
            urlRepository.delete(url);
        }
    }


    private String generateShortUrl() {
        // Génération mini URL
        return null;
    }

    private String generateRemovalToken() {
        // Génération token suppression
        return null;
    }

}