package com.sncf.shortenerapi.Model;


public class Url {
    private final Long id;
    private final String shortUrl;
    private final String realUrl;
    public Url(Long id, String shortUrl, String realUrl) {
        this.id = id;
        this.shortUrl = shortUrl;
        this.realUrl = realUrl;
    }

    public Object getRemovalToken() {
        return null;
    }

}


//
////    Url(String shortUrl, String realUrl) {
////
////        this.shortUrl = shortUrl;
////        this.realUrl = realUrl;
////    }
//
//    public Long getId() {
//        return this.id;
//    }
//
//    public String getShortUrl() {
//        return this.shortUrl;
//    }
//
//    public String getRealUrl() {
//        return this.realUrl;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public void setShortUrl(String shortUrl) {
//        this.shortUrl = shortUrl;
//    }
//
//    public void setRealUrl(String realUrl) {
//        this.realUrl = realUrl;
//    }

