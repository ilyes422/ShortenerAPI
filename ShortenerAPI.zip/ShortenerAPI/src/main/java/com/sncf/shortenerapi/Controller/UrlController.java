package com.sncf.shortenerapi.Controller;

import com.sncf.shortenerapi.Model.Url;
import com.sncf.shortenerapi.Service.UrlService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;


@RestController
@RequestMapping("/links")
public class UrlController {

    private final UrlService urlService;

    public UrlController(UrlService urlService) {
        this.urlService = urlService;
    }

    @GetMapping
    public List<Url> getAllUrls() throws IOException {
        return urlService.getUrls();
    }

    @PostMapping
    public Url createShortUrl(@RequestBody String url) throws IOException {
        return urlService.createShortUrl(url);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUrl(@PathVariable String id,@RequestHeader("X-Removal-Token") String token) throws IOException {

        urlService.deleteUrl(id, token);
        return ResponseEntity.noContent().build();

    }

}